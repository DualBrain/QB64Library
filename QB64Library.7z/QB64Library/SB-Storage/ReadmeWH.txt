The WH (with handle) version is a special edition of the Stringbuffer
System, which is extended to allow multiple handles on every buffer array,
while the regular version does only allow one buffer per array.

That is, with the regular version you need to REDIM a new array for every
buffer you need, hence the buffer (array name) must be known at the time
of writing/compiling the program.
  Obviously you may meet situations where it is required to dynamically
create new buffers with a handle, just as you eg. open new files with a
new channel number. This is what the WH version is providing, you just
need one array and then you can create multiple buffers on the same array
but with different handle numbers.

I've not explicitly changed the HTML documentation for the WH version, as
the only difference between the regular and the WH function calls is the
need to additionally designate the desired handle, which is always inserted
as the 2nd function argument right after the buffer array name.

Exceptions are the two functions which need two buffer specifications:
  CopyBuf (buf$(), han%, destBuf$(), dhan%)
  BufInsertBuf (buf$(), han%, fromBuf$(), fhan%)
As you see, you have to provide two arrays/handles for each call here.

